# Lakas-Ng-Thrift
 By: Hilary Llanes, MJ Bucio, Naomi Teodoro, Jasmine Dagami
